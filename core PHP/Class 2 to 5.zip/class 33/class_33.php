
<?php 
define("HOST",3789473298);

// echo HOST;

// define("HOST",0);
// < less than
// > greater than
// <= less than or equal to
// >= greater than or equal to
// == equal to
// === identical to
// != not equal to
// !== not identical to

// Check two given numbers and return true if one of the numbers is 50 or if their sum is 50.
// Check from the given integer, whether it is positive or negative.
// Check whether a given number is even or odd.
// Determine whether a given year is a leap year.
$input_text = 'Initial message';

// modular program


function MyDisplay(){

$input_text="";



$inut_text="value has been changed by function";

 
}

MyDisplay();


// echo $input_text;


interface  Animal 
{
  function eat();
  function walk();
}






abstract class ParentClass {
 public $name;
abstract function display(); // declare 
}

// interface a {

//   public function someMethod1();

// }

//  class class_33 extends ParentClass implements a
// {
//  function display(){
// //define
//  }
 
//  function someMethod1(){
// //define
//  }
 
// }

// class Class_33{
//  public static $class_33= "";

//  public static function ABC(){

//  }
// }


// $abc= new Class_33();
// Class_33::$class_33;
// Class_33::ABC();

$fn1 = fn($dsa="default")=> var_dump($dsa);

$num1=799;

echo $fn1();

// $qwer=function(){

// };
// function display($a="default Value") {

//  // var_dump($a);
// return $a;

// }


// $abc="this value has been changed";

// echo display($abc);

// $outputVar = function ($local="abc") {  //by default value

//  var_dump($local);
 
// };




$num1= 25;

$num2=50;

// if($num1 < 0){
// echo "Negative";
// }else{
//  echo "positive";
// }





// $sum = $num1 + $num2;
// ternary operator

// $abc= ( ( ($num1 == 50 ) || ($num2 == 50) ) || $sum == 50) ? true : false;


// if ( ( ($num1 == 50 ) || ($num2 == 50) ) || $sum == 50 ) {

//  echo true;

// }
// else {
//  echo false;
// }

// if(($num1 == 50 ) || ($num2 == 50) ){
//  echo ("any of the number is 50".true);
// }
// elseif($sum == 50){
// echo ("their sum is 50 :". true);
// }






?>