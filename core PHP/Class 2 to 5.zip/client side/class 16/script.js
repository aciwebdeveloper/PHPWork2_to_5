// user define - build in function
/* 
1. default/normal function with no return
2. parameterize/argument function with no return
3. parameterize/argument function with return 
4. default/normal function with return
5. arrow function
*/
function add() { //default/normal function with no return
 console.log("calling by function")
}

add() //invoke

function add(e, r) { //parameterize/argument function with return 

 var z = e + r;

 return z;
}


function checkEvenOdd(number) {

 if (number == "") {
  document.getElementById("result").innerHTML = "Please fill the field"
  document.getElementById("result").style.color = "red"
 }
 else {
  
  document.getElementById("result").style.color = "black"

  if (number % 2 == 0) {
   // alert("EVEN")
   document.getElementById("result").innerHTML = "EVEN"
   // return "EVEN";
  } else {
   // alert("ODD")
   document.getElementById("result").innerHTML = "ODD"
   // return "ODD";
  }
 }


}

// console.log(checkEvenOdd(20))

// console.log(checkEvenOdd(99))


console.log(add(2, 5))

console.log(add(7, 8))