// 1. default/normal function with no return

// function Adds(){

//  console.log("function invoke");

// }
// ==============================================================
// 2. parameterize/argument function with no return
// var z;

// Add(5,7)
// console.log(z)
// Add(12,7)
// console.log(z)
// Add(16,7)
// console.log(z)
// local variable , global variable


// function Add(a,b) {
//  z = a+b;
// console.log(z)

// }



// 3. parameterize/argument function with return
// var y=a+b;
// return z;
// z++ 
// z=z+1

function Add(a, b) {
 var z = a + b;

 // a++;
 // document.querySelector("#result").innerHTML+="Sum is: " + z +"<br>";
 // a=a+1;
 document.querySelector("#result").innerHTML =
  document.querySelector("#result").innerHTML + "Sum is: " + z + "<br>";

} 

Add(5, 7)
Add(12, 7)
Add(16, 7)

// concatination (+)

// console.log(Add(6,7))



// 4. default/normal function with return
// 5. arrow function 


