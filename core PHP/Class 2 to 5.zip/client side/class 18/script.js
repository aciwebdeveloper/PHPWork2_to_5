function Multiply(num1,num2){
 let result = num1 * num2;

 console.log(result)

}

function Multiply() {
 return "ok"
}

(()=>{

})



// console.log(Multiply())











const GuessNumber = (() => {
 var q=document.querySelector("#guess").value

 var random = Math.floor(Math.random() * (1+100 ) +1)
 
 
 console.log(random)

})
//guess the number by computer and match that number by user input
/*
logic_1 : treat random variable globally then check that variable to the user input and show result 
logic_2: treat random variable locally then check that variable to the user input and show result 
*/





const abc = (function (a, b) {
 var z = a * b;

 document.querySelector("#res").innerHTML = "Sum IS :" + z + "<br>"
});
abc(2, 3)
// arrow function
const qwer = ((q, t) => {
 let z = q * t
 document.querySelector("#res").innerHTML += "Multiply is:" + z + "<br>"
});
qwer(2, 7)
// 35
// 45
// 75

// Find the area of a rectangle where the length is 5 and the width is 8.
// Find the area of a triangle where the base is 4 and the height is 3.
// Find the area of a circle where the radius is 3.
// Convert temperatures from Celsius to Fahrenheit and Fahrenheit to Celsius.




