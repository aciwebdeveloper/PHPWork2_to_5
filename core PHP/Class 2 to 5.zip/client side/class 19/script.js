

// a.unshift("ok")
// a.pop()


// a[2];
// a[4];
let a = [5, 18, 9, "abc", true, 9, 24, 7, 8] // length 8 range [0-7]
let b = ["bElement", "element 2"]

a[a.length - 1]


let concat = a.concat(b);

let start = 0;

let end = a.length - 1; // range

let mid = Math.ceil((end + start) / 2) - 1

// let slice=a.slice(0 , (mid+1))
// let splice= a.splice(2,1,"newValue")


// delete a[2];

// console.log(a.join(" +"))





// console.log("before push() INsert: "+ a)

// a.push("newValue",2)


// console.log("After push() INsert: "+ a)

// ===========================================================
// console.log("before unshift() INsert: "+ a)

// a.unshift("newValueBYShift",2)


// console.log("After unshift() INsert: "+ a)





// 0  1    2    3   4
// a=5;
// if (Array.isArray(a)) {
//  console.log("this variable is an array")
// }
// else {

//  console.log("this variable is not an array")
// }

// console.log(a)
// console.log(typeof a)
// let q[10];

let min = 1;
let max = 100;
let COmputerNumber = Math.floor(Math.random() * (max - min) + min)

const GuessGame = (() => {

 let UserInput = document.querySelector("#input").value;
 // console.log(UserInput)
 if (UserInput > COmputerNumber) {
  console.log("Too High" + " " + "Computer Guess is:" + COmputerNumber)
 }
 else if (UserInput < COmputerNumber) {
  console.log("Too Close" + " " + "Computer Guess is:" + COmputerNumber)
 }
 else {
  console.log("matched" + " " + "Computer Guess is:" + COmputerNumber)
 }

})
