/*
,make this by using for loop

*
**
***
****
*****
******
*******
nested loop
*/

let array = [
 Math.floor(Math.random() * 100),
 Math.floor(Math.random() * 100),
 Math.floor(Math.random() * 100),
 Math.floor(Math.random() * 100),
 Math.floor(Math.random() * 100),
 Math.floor(Math.random() * 100),
 Math.floor(Math.random() * 100)
];// length 7 range [0-6]

// array[0]
// for(start ; condition/ending ; increament/decreament){

// }
let length = (array.length - 1) //5
let print = ""; //3 6 7   23
//            6     5

for (let i = 0; i <= length; i++) {
 print += i + " : " + array[i] + "<br>";
}



document.querySelector("#demo").innerHTML = print





//  sort in alphabets and numric
// let array = ["abc","ert","qwe","btweq"];
// let array = [3, 6, 7, 9, 14, 23];
//  In numeric
// let Abc = array.sort(function (a, b) {
//  return (a - b)
// })


// console.log(Abc)



// ===================map function in Array========================
// let array = [3, 6, 7, 9, 14, 23,"abc"]

// let newArray = array.map(function (val) {
//  return (val + 1)
// })
// console.log(newArray)
// ===========================================
// Every function in Array
// let array = [3, 6, 7, 9, 14, 23, 2]

// let newArray = array.every(function (a) {
//  return a > 18
// })

// console.log(newArray)


// filter function in array
// let array = [3, 6, 7, 9, 14,23, 2]

// let newArray = array.filter(function (val) {
//  return val > 7;
// })

// console.log(newArray)

