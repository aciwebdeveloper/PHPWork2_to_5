/* 
*
****
****
****
****
****

*/


// let asterik = " ";
let ending = 6;
let valuesss="";
for (let rows = ending ; rows >= 0 ; rows--) {

 for (let cols = 1; cols <= rows; cols++) {

  valuesss += cols + " &nbsp;"


 }
 valuesss += "<br>"
}

document.querySelector("#star2").innerHTML=valuesss 


let abc = [34, "abc", true, 321, 4324, 543];
// abc.reverse()
// abc.forEach(function(val){
// console.log(val)
// })

// Sum all the array elements by using a loop.
// Reverse the array by using a loop.
// Make a table of the given number with all possible loops. 

// let abc= {
//  "name":"XYZ",
//  "number": 23,
// }
index =2;

let arrayes = [
 ["first CHild array", 23, 54, 76, 324],

 ["second CHild array", 23, 43, 65, 7634, 2],

 ["Third ", 54, 6532, 23, 54, 654, 875876, 5643, 2432, 432, 432432, 6543, 654]

]

// console.log(arrayes[0][4])
let rowLength = arrayes.length; // parent array length
let valuess = "";
// outer loop rows handling start
for (let rows = 0; rows < rowLength; rows++) {

 let colLength = arrayes[rows].length; // child array length
//  inner loop columns handling  start
 for (let cols = 0; cols < colLength; cols++) {
  valuess += arrayes[rows][cols]+ " &ensp;"
 }
// inner loop end
 valuess += "<hr>"

}
// outer loop emd

// document.querySelector("#star2").innerHTML = valuess
// let index = 0;

// for (const row of arrayes) {

//  for (const col of arrayes[index]) {
//   console.log(col)
//  }

//  index++;
// }


// for (const key in abc) {
//  console.log(abc[key])
// }


// let start = 1;
// let values = "";

// do {
//  values += start + " <br> <hr>"
//  start++
// } while (start < 1);

// document.querySelector("#star").innerHTML = values



// for(let start=1; start< 10 ; start++){

// }


// let start =1;

// let values="";

// while (start < 10) {

//  values+= start + "<br>"


//  start++;

// }

// document.querySelector("#star").innerHTML=values



let limit = 9;
let star = "";

// let abc= [

// ]
// 2d arrays
let arrays = [
 ["first CHild array", 23, 54, 76, 324],
 ["second CHild array", 23, 43, 65, 7634, 2],
 [34, 54, 6532, 23, 54, 654, 875876, 5643, 2432, 432, 432432, 6543, 654]
]


// console.log(arrays)

// let value = "";
// // outer loop  rows
// for (let row = 0; row < arrays.length; row++) {


//  value += "Row Number : " + (row + 1) + "<br> Total Column :" + arrays[row].length + "<br>"
//  // inner loop columns  13       13
//  for (let col = 0; col < arrays[row].length; col++) {

//   value += (col + 1) + ": " + arrays[row][col] + "<br>"
//  }


//  value += "<br> <hr>"
// }

// document.querySelector("#star").innerHTML = value



// for (let row = limit ; row >= 1; row--) {

//  for (let col = 1; col <= row; col++) {
//   star += "*"
//  }

//  star += "<br>"

// }

// document.querySelector("#star").innerHTML = star