// Make an object to store the information of a student and iterate with a for-in loop.

let student = {
 name: "John",

 RegNum: "357TR",

 fees: 30000,

 subjects: {
  computer: 97,
  Math: 97,
  Physics: 99
 },


 languages: ["PHP", "C#", "Python"]
}
// student["subjects"]["Math"]
// student.languages

for (const key in student){
// console.log(typeof student[key])
 if (typeof student[key] == "object") {

  for (const CHILDKey in student[key]) {

   console.log(key + "=>" + CHILDKey + ":" + student[key][CHILDKey])

  }


 }
 else {
  console.log(student[key])
 } 

}

























// object
// let abc = {

//  name: "XYZ",
//  number: 654,

//  marks: {
//   physics: 99,
//   Math: 85
//  }
// }



// abc.forEach(element => {
//  console.log(element)
// });
// console.log(abc.marks.Math)

// for (const key in abc) {

//  if (typeof abc[key] == "object") {


//   for (const keyS in abc[key]) {

//    console.log(keyS + ":" + abc[key][keyS])

//   }
//  }
//  else {

//   console.log(key)

//  }
// }





//  find the largest value in array
// let array = [23, 54, 654, 767777777758, 76, 432432, 134444444]
// let maxValue = "";

// for (let select = 0; select < array.length; select++) { // value select

//  isGreater = true;

//  for (let check = 0; check < array.length; check++) {

//   if (array[select] <= array[check] && select !== check) {

//    isGreater = false;
//    break;

//   }

//  }


//  if (isGreater) {
//   maxValue = array[select]
//  }


// }


// console.log(maxValue)