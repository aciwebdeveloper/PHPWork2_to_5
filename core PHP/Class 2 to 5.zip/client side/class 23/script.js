
let div = document.querySelector("#demo") // div ID

div.classList.add("WRITTEN_BY_js")

for (let index = 1; index <= 3; index++) {
 
// h1 creation


 // paragraph creation
let p_Tag = document.createElement("p")

let p_content = document.createTextNode("Paragraph written by JS")

p_Tag.appendChild(p_content)


div.appendChild(p_Tag)


let h1 = document.createElement("h1"); // h1 tag creation  

let content = document.createTextNode("Heading written by JS") // h1 content

h1.appendChild(content) // insert that content in h1 tag 

p_Tag.before(h1)


// button creation
let button = document.createElement("button")

let BUttonContent = document.createTextNode("X")

button.classList.add("Add")

button.appendChild(BUttonContent)



p_Tag.appendChild(button)

 
}


let GetButtons = document.querySelectorAll(".Add");

console.log(GetButton)


















// document.queryS document.querySelector("#demo").innerHTML="<h1> heading 1 </h1>"elector("#demo").innerHTML="<h1> heading 1 </h1>"
//  document.querySelector("#demo").innerText="<h1> heading 1 </h1>"

// query selectorall with loop
// let input = document.querySelectorAll("input[type=text]")


// console.log(input)

// for (let index = 0; index < input.length; index++) {
//  input[index].value = `print by js ${index}`
// }

// syntax
// camel case

// background-color

// backgroundColor
