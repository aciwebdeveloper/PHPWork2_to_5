let div = document.querySelector("#demo")

for (let index = 1; index <= 3; index++) {



 let p = document.createElement("p");

 let p_content = document.createTextNode("write By JS" + index);

 p.appendChild(p_content);

 let button = document.createElement("button");

 let button_content = document.createTextNode("X");

 button.classList.add("remove")

 button.appendChild(button_content);

 p.appendChild(button)

 div.appendChild(p)

}




// console.log(selectButton)


let selectButton = document.querySelectorAll(".remove")

for (let index = 0; index < selectButton.length; index++) {

 selectButton[index].addEventListener("click", function () {

  this.parentElement.style.backgroundColor = "red";
  this.parentElement.style.color = "white";
  this.parentElement.style.transition = "opacity 1s ease-in-out";
  selectButton[index].parentElement.style.opacity = "1";

  setTimeout(function () {

   selectButton[index].parentElement.style.opacity = "0";

   setTimeout(function () {
    selectButton[index].parentElement.remove()
   },1000)

  }, 1000)








 })


}

// let button=document.querySelector("#Click")

// button.addEventListener("click",function(e){
// // console.log(e)

// getAttr.classList.toggle("abc1")

// })


// single class remove
// getAttr.classList.remove("abc1")

// remove attribute
// getAttr.removeAttribute("class")

// get Attribute
// console.log( getAttr.getAttribute("class")

// set attribute
// console.log( getAttr.setAttribute("class","byJavacsript abc1"))

// add class by using js
// getAttr.classList.add("byJavacsript")
// getAttr.classList.add("abc23")