
//  these are the selectors only
// let username = document.forms["Form1"]["user_name"];
let user_name = document.querySelector("#user_name");

// let form = document.forms["Form1"];
let form = document.querySelector("#Form1")

let submit = document.querySelector("#submit"); // submit button selector

let user_nameError = document.querySelector("#user_nameError") // span tag error or messege selector



function checking() {

 if (username.value == "") {


  user_nameError.style.color = "red"
  user_nameError.innerHTML = "Please fill the field"

  return false;

 } else {

  user_nameError.style.color = "black"
  user_nameError.innerHTML = username.value

 }
}

let password = document.querySelector("#password");
let confrmPass = document.querySelector("#confirm_password");

let showHide = document.querySelector("#reveal")
let eye = document.querySelector("#reveal > i")
showHide.addEventListener("click", function () {

 if (password.type == "password") {

  password.setAttribute("type", "text")
  
  confrmPass.setAttribute("type", "text")

  eye.classList.remove("fa-eye")
  eye.classList.add("fa-eye-slash")

 } else {
  password.setAttribute("type", "password")
  confrmPass.setAttribute("type", "password")



  eye.classList.remove("fa-eye-slash")
  eye.classList.add("fa-eye")
 }

})


confrmPass.addEventListener("keyup", function () {

 if (password.value !== confrmPass.value) {

  user_nameError.style.color = "red"
  user_nameError.innerHTML = "Password did not matched"
  

 }
 else {
  user_nameError.style.color = "green"
  user_nameError.innerHTML = "Password  matched"

 }
})




form.addEventListener("submit", function (e) {

 if (username.value == "") {

  e.preventDefault();

  user_nameError.style.color = "red"
  user_nameError.innerHTML = "Please fill the field"

 } else {
  user_nameError.style.color = "black"
  user_nameError.innerHTML = username.value
 }

})