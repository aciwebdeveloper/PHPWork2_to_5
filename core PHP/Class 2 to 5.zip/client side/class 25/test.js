let assoc={
 name:"XYZ",
 address:"ueiwqupoiew",
std:function(){
 console.log("ok")
}
}



console.log(assoc.std())

let array = [12, 34, 54, 65] //1d array

let SecondDimension = [
 ["first Child", 34, 54, 64],
 ["Second Child", 34, 54, 65]

]
console.log(SecondDimension)


for (const row in SecondDimension) {

 for (const col in SecondDimension[row]) {
  console.log(SecondDimension[row][col])
 }

}
console.log("-====================================-")

for (let row = 0; row < SecondDimension.length; row++) {

 for (let col = 0; col < SecondDimension[row].length; col++) {

  console.log(SecondDimension[row][col])
 }

}
