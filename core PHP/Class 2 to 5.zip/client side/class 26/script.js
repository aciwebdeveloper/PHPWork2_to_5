let form = document.querySelector("#form");

let userName = document.querySelector("#user_name");
let _error = document.querySelector("#Error")

_error.innerHTML = userName.type

form.addEventListener("submit", function (event) {

 if (userName.value == "") {
  
  event.preventDefault();

  _error.innerHTML = "please Fill the Field"
 }

})

let option = document.querySelector("#test")
let check = document.querySelectorAll(".check");

// console.log(check[3])

for (let index = 0; index < check.length; index++) {

 check[index].addEventListener("click", function () {
  console.log(this.innerHTML)
 })

}


option.addEventListener("click", function () {

 console.log(this.value)

})
// stringlength(userName, 6, 10)

function stringlength(inputtxt, minlength, maxlength) {
 var field = inputtxt.value; // length :9
 var mnlen = minlength; //6
 var mxlen = maxlength; //10
 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
 //            F                    F          
 if (field.length < mnlen || field.length > mxlen) {

  alert("Please input the userid between " + mnlen + " and " + mxlen + " characters");

  return false;
 }
 else {
  alert('Your userid have accepted.');
  return true;
 }
}


let quizDetail =
 [
  {
   question: [""],
   option: ["", "", "", ""],
   correctOPtion: "jdklsajlk"
  },
  {
   question: [""],
   option: ["", "", "", ""],
   correctOPtion: "jdklsajlk"
  }
 ]
