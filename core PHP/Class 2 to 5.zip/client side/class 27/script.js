
let quizDetail =
        [
                {
                        question: "Which is the most widely spoken language in the world?",
                        options: ["Spanish", "Mandarin", "English", "German"],
                        correct: "Mandarin",
                },
                {
                        question: "Which is the only continent in the world without a desert?",
                        options: ["North America", "Asia", "Africa", "Europe"],
                        correct: "Europe",
                },
                {
                        question: "Who invented Computer?",
                        options: ["Charles Babbage", "Henry Luce", "Henry Babbage", "Charles Luce"],
                        correct: "Charles Babbage",
                }
        ];

let quizContainer = document.querySelector("#quiz-container");
let question = document.querySelector("#question");
let options = document.querySelector("#option");
let NextButton = document.querySelector("#Next");
let error = document.querySelector("#Error");

let index = 0;
let score = 0;

let WrongAnswer = [];

function Shuffle(array) {
// length :7 range: 6
        for (let x = (array.length - 1); x >= 0; x--) {


                let j = Math.floor(Math.random() * x); //3

                temp = array[x];

                array[x] = array[j];

                array[j] = temp;
        }



}









Shuffle(quizDetail)
Shuffle(quizDetail[index].options)
NextButton.addEventListener("click", function () {

        checkAnswer()

})


function DisplaYQuiz() {
        let question = document.querySelector("#question");
        let options = document.querySelector("#option");
       

        if (document.querySelector("#wrong")) {
                // console.log("ok")
                document.querySelector("#wrong").remove()
        }

        let currentMCQ = quizDetail[index];
        // alert()
        // console.log(currentMCQ)
        question.innerHTML = " "
        question.innerHTML = currentMCQ.question;

        console.log(question)
        let Displayoptions;

        options.innerHTML = " "

        currentMCQ.options.forEach(function (val) {

                // INput Tag Creation type Radio
                Displayoptions = document.createElement("input");
                Displayoptions.type = "radio";
                Displayoptions.classList.add("OPT");
                Displayoptions.name = "quiz"
                Displayoptions.value = val

                options.appendChild(Displayoptions)

                // span Tag CreaTion

                let span = document.createElement("span");
                content = document.createTextNode(val);

                span.appendChild(content)


                Displayoptions.after(span);

                // console.log(Displayoptions)
                // Displayoptions.after(val)

        })

        // correct this logic by yourself where index greater = 0



}

DisplaYQuiz()

function checkAnswer() {

        let currentMCQ = quizDetail[index];
        let Answer = currentMCQ.correct;

        let AllOPtions = document.querySelectorAll(".OPT")

        let optionLength = AllOPtions.length;

        for (let range = 0; range < optionLength; range++) {

                if (AllOPtions[range].checked == true) {


                        error.innerHTML = "";

                        if (AllOPtions[range].value == Answer) {
                                score++;

                                console.log(AllOPtions[range].value)

                        }
                        else {
                                WrongAnswer.push({
                                        question: currentMCQ.question,
                                        YourAns: AllOPtions[range].value,
                                        Correct: Answer
                                })
                        }

                        break;
                }
                else {

                        error.style.color = "red"
                        error.innerHTML = "Kindly select any one"
                }

        }

        if (error.innerHTML == "") {

                index++;
        }

        let range = (quizDetail.length - 1)
        if (index <= range) {
                DisplaYQuiz()
        } else {
                ShowResult()

        }



}






function ShowResult() {
        // quizContainer.innerHTML = " "

        options.innerHTML = " ";
        question.innerHTML = " ";
        let scoreDiv = document.createElement("div")
        scoreDiv.id = "score"
        let content = document.createTextNode(`Your SCore is: ${score}`);

        scoreDiv.appendChild(content);

        quizContainer.appendChild(scoreDiv)

        // console.log(WrongAnswer)
        let WrongDisplaYAns = "<div id='wrong'>";

        if (WrongAnswer.length > 0) {

                for (let index = 0; index < WrongAnswer.length; index++) {
                        WrongDisplaYAns += `<hr><div ="wrog"> 
             Question : ${WrongAnswer[index].question}<br>
             Your Selected OPtion : ${WrongAnswer[index].YourAns}<br>
             Correct Answer : ${WrongAnswer[index].Correct}
                     </div><hr>`;

                }



        } else {
                WrongDisplaYAns = " <span id='messege'> COngratulation! YOU WON </span> <br>";

        }

        WrongDisplaYAns += "<button onclick='restart()' id='restart'> Restart </button> </div>"
        quizContainer.innerHTML += WrongDisplaYAns

        NextButton.addEventListener("click", function () {

                checkAnswer()

        })

}


function restart() {
        // alert("ok")
        let restart = document.querySelector("#restart");
        restart.remove();
        if (document.querySelector("#messege")) {
                let messege = document.querySelector("#messege");
                messege.remove();
        }

        let scoreDiv = document.querySelector("#score")
        scoreDiv.remove()
        index = 0;

        score = 0;
        WrongAnswer = [];

        Shuffle(quizDetail)
        DisplaYQuiz()
        NextButton.addEventListener("click", function () {

                checkAnswer()

        })


}


