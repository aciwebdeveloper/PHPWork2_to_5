let input = document.querySelector("#todo_list");
let button = document.querySelector("#add");
let ol = document.querySelector("#list");
let error = document.querySelector("#error");

// by using enter 
input.addEventListener("keyup", function (event) {
 if (event.key == "Enter") {

  let value = input.value;
 
  if (value == "") {
   error.style.color = "red";
   error.style.fontWeight = "bolder";
   error.innerHTML = "please fill the Field";

  }
  else {
   error.innerHTML = "";

   let li = document.createElement("li");
   let li_content = document.createTextNode(value);

   li.appendChild(li_content);
   ol.appendChild(li);

   let removeBtn = document.createElement("button");
   let removeContent = document.createTextNode("x");
   // removeBtn.classList.add("remove");
   removeBtn.onclick = (() => {
    removeBTN(removeBtn)
   })
   removeBtn.appendChild(removeContent);

   li.appendChild(removeBtn)

   input.value = ""

  }
 }

})




button.addEventListener("click", function () {
 let value = input.value;

 if (value == "") {
  error.style.color = "red";
  error.style.fontWeight = "bolder";
  error.innerHTML = "please fill the Field";

 }
 else {
  error.innerHTML = "";

  let li = document.createElement("li");
  let li_content = document.createTextNode(value);

  li.appendChild(li_content);
  ol.appendChild(li);

  let removeBtn = document.createElement("button");
  let removeContent = document.createTextNode("x");
  // removeBtn.classList.add("remove");
  removeBtn.onclick = (() => {
   removeBTN(removeBtn)
  })
  removeBtn.appendChild(removeContent);

  li.appendChild(removeBtn)

  input.value = ""

 }

})


function removeBTN(a) {
 let parent = a.parentElement;

 parent.style.backgroundColor = "red";
 parent.style.color = "white";
 parent.style.transition = "opacity 1s ease-in-out";

 setTimeout(function () {
  parent.style.opacity = "0";

  setTimeout(function () {
   parent.remove();
  }, 1000)

 }, 1000)



 // let removeBTNSelect = document.querySelectorAll(".remove");

 // for (let index = 0; index < removeBTNSelect.length; index++) {

 //  removeBTNSelect[index].addEventListener("click", function () {

 //   console.log(removeBTNSelect[index].parentElement)

 //  })
 // }

}
