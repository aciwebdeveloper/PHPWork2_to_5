
let locations = document.querySelector("#loc");
let button = document.querySelector("#enter");
let input = document.querySelector("#Loc_name");
let result =document.querySelector("#result");

function Value(val){

 result.value += val
}



function equal(val){
if(val == "="){

 try {
  
  
  result.value=eval(result.value)
 
  
 } catch (error) {
console.log(error)
  alert("This value is not valid")
 
 }

}
}

button.addEventListener("click", function () {
 WeatherApi()
})

async function WeatherApi() {
 let location = input.value;
 let appId = "efa7a925fb026da148c38da6a7675753";

 let response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&APPID=${appId}`)

 let data = await response.json()
 // console.log(data)

 locations.innerHTML =`${data.weather[0].main } <br>
  ${data.weather[0].description}
 `


 // for (const key in data) {
 //  if (typeof data[key] == "object") {
 //   for (const childKey in data[key]) {



 //    if (typeof data[key][childKey] == "object") {

 //     for (const childsKey in data[key][childKey]) {
 //      locations.innerHTML += `${childsKey} : ${data[key][childKey][childsKey]} <br>` 
 //     }
 //    } else {
 //     locations.innerHTML += `${childKey} : ${data[key][childKey]} <br>`
 //    }


 //   }
 //  }
 //  else {
 //   locations.innerHTML += `${key}: ${data[key]} <br>`
 //  }



 //  console.log(key)
 // }

 console.log(data)

}



